import React from 'react'
import SampleClassComponent from './SampleClassComponent'
import Trainee from './Trainee'

const FitaAcademy = () => {
    const name = 'Peermohamed'

    return (
        <>
            <div>FitaAcademy</div>
            <Trainee name={name} age={18} gender="Male" />
            <SampleClassComponent />
        </>
    )
}

export default FitaAcademy