import React from 'react'

function Trainee(props) {
    //Destructure the props value
    const { name, age, gender } = props 
    console.log(props, "Props");
    const text = `Hi Am ${name} am learning React. am ${age} years old, ${gender}`

    return (
        <div>
            <h1>{text}</h1>
        </div>
    )
}

export default Trainee