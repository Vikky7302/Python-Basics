import React, { Component } from 'react'

class SampleClassComponent extends Component {
    render() {
        return (
            <div>Hi am a ClassComponent</div>
        )
    }
}

export default SampleClassComponent