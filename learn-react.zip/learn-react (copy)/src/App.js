import logo from './logo.svg';
import './App.css';
import Trainee from './components/Trainee';
import FitaAcademy from './components/FitaAcademy';

function App() {
  return (
    <div className="App">
      <h1>Learn React</h1>
      {/* <Trainee /> */}
      <FitaAcademy />
    </div>
  );
}

export default App;
